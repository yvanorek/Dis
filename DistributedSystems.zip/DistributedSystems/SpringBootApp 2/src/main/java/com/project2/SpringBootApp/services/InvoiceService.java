package com.project2.SpringBootApp.services;

import com.project2.SpringBootApp.config.RabbitMQConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Slf4j
@Service
public class InvoiceService {

    private final RabbitTemplate rabbitTemplate;

    @Autowired
    public InvoiceService(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void startInvoiceGeneration(String customerId) {
        rabbitTemplate.convertAndSend(RabbitMQConfig.INVOICE_QUEUE_NAME, customerId);
    }


    public ResponseEntity<?> getInvoice(String customerId) {
        boolean invoiceAvailable = isInvoiceAvailable(customerId);

        if (invoiceAvailable) {
            return ResponseEntity.ok().body("Invoice available to be Downloaded");
        } else {
            return ResponseEntity.status(404).body("Invoice not available yet");
        }
    }

    // Helper method to simulate checking if the invoice is available
    public boolean isInvoiceAvailable(String customerId) {
        return true; // Default implementation, to be overridden in tests
    }
}
