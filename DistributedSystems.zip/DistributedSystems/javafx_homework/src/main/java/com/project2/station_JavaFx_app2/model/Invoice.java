package com.project2.station_JavaFx_app2.model;

public class Invoice {
    private Long customerId;
    private String filePath;

    public Invoice(Long customerId, String filePath) {
        this.customerId = customerId;
        this.filePath = filePath;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
