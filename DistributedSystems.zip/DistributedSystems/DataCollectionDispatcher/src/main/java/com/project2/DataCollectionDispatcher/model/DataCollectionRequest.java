package com.project2.DataCollectionDispatcher.model;

public class DataCollectionRequest {
    private String customerId;

    public DataCollectionRequest() {
    }

    public DataCollectionRequest(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
