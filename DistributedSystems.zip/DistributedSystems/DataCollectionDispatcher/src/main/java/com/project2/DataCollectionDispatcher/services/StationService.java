package com.project2.DataCollectionDispatcher.services;

import com.project2.DataCollectionDispatcher.config.RabbitMQConfig;
import com.project2.DataCollectionDispatcher.entity.Station;
import com.project2.DataCollectionDispatcher.repository.StationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StationService {
    private static final Logger log = LoggerFactory.getLogger(StationService.class);

    @Autowired
    private StationRepository stationRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public List<Station> getAllStations() {
        return stationRepository.findAll();
    }

    public void startDataGatheringJob(Long messageId) {
        List<Station> stations = getAllStations();
        for (Station station : stations) {
            log.info("Sending message to Station Data Collector: {}", messageId);
            rabbitTemplate.convertAndSend(RabbitMQConfig.STATION_DATA_QUEUE_NAME, messageId);
        }
        log.info("Sending message to Data Collection Receiver: {}", messageId);
        rabbitTemplate.convertAndSend(RabbitMQConfig.DATA_COLLECTION_RECEIVER_QUEUE_NAME, messageId);
    }
}
