package com.project2.DataCollectionReceiver;



import static org.mockito.Mockito.*;

import com.project2.DataCollectionReceiver.services.DataCollectionReceiverService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

public class DataCollectionReceiverServiceTest {

    // Mocking the RabbitTemplate to verify interactions
    @Mock
    private RabbitTemplate rabbitTemplate;

    // Injecting the mocks into the service we want to test
    @InjectMocks
    private DataCollectionReceiverService dataCollectionReceiverService;

    // Initializing mocks before each test
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Test to verify that no message is sent when only customerId is processed
    @Test
    public void testProcessCustomerId() {
        Long customerId = 12345L;
        dataCollectionReceiverService.processCustomerId(customerId);
        // Verify that no message is sent yet
        verify(rabbitTemplate, never()).convertAndSend(anyString(), anyString());
    }

    // Test to verify that no message is sent when only kWh is processed
    @Test
    public void testProcessKwh() {
        Double kwh = 678.9;
        dataCollectionReceiverService.processKwh(kwh);
        // Verify that no message is sent yet
        verify(rabbitTemplate, never()).convertAndSend(anyString(), anyString());
    }

    // Test to verify that a message is sent when both customerId and kWh are processed
    @Test
    public void testSendMessageIfReady() {
        Long customerId = 12345L;
        Double kwh = 678.9;

        // Process both customerId and kWh
        dataCollectionReceiverService.processCustomerId(customerId);
        dataCollectionReceiverService.processKwh(kwh);

        // Expected message format
        String expectedMessage = customerId + "," + kwh;

        // Verify that the message is sent once
        verify(rabbitTemplate, times(1)).convertAndSend("pdfGeneratorQueue", expectedMessage);
    }

    // Test to verify that the service resets its state after sending a message
    @Test
    public void testSendMessageIfReadyReset() {
        Long customerId = 12345L;
        Double kwh = 678.9;

        // Process both customerId and kWh
        dataCollectionReceiverService.processCustomerId(customerId);
        dataCollectionReceiverService.processKwh(kwh);

        // Verify that the message is sent once
        verify(rabbitTemplate, times(1)).convertAndSend("pdfGeneratorQueue", customerId + "," + kwh);

        // Check if values are reset after sending the message by processing new values
        dataCollectionReceiverService.processCustomerId(customerId);
        dataCollectionReceiverService.processKwh(kwh);

        // Verify that the message is sent again
        verify(rabbitTemplate, times(2)).convertAndSend("pdfGeneratorQueue", customerId + "," + kwh);
    }
}
