package com.project2.DataCollectionReceiver.listener;

import com.project2.DataCollectionReceiver.model.DataCollectionJob;
import com.project2.DataCollectionReceiver.services.DataCollectionReceiverService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DataCollectionReceiverListener {

    private static final Logger log = LoggerFactory.getLogger(DataCollectionReceiverListener.class);

    @Autowired
    private DataCollectionReceiverService dataCollectionReceiverService;

    @RabbitListener(queues = "dataCollectionReceiverQueue")
    public void receiveCustomerId(Long customerId) {
        log.info("Received message with customerId: {}", customerId);
        dataCollectionReceiverService.processCustomerId(customerId);
    }

    @RabbitListener(queues = "kwhQueue")
    public void receiveKwh(Double kwh) {
        log.info("Received message with kwh: {}", kwh);
        dataCollectionReceiverService.processKwh(kwh);
    }
}
