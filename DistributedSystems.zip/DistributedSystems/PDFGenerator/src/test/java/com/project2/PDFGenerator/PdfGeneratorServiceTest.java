package com.project2.PDFGenerator;

import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import com.project2.PDFGenerator.services.PdfGeneratorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

public class PdfGeneratorServiceTest {

    @Mock
    private CustomerRepository customerRepository; // Mock des CustomerRepositorys, um Datenbankzugriffe zu simulieren

    @InjectMocks
    private PdfGeneratorService pdfGeneratorService; // InjectMock, um die PdfGeneratorService-Klasse zu testen

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialisiert die Mock-Objekte vor jedem Test
    }

    @Test
    void generateInvoiceTest() {
        Long customerId = 1L; // Beispielkunden-ID
        Double kwh = 100.0; // Beispiel für Kilowattstunden

        // Erstellen eines Beispielkunden
        Customer customer = new Customer();
        customer.setId(customerId);
        customer.setFirstname("John");
        customer.setLastname("Doe");

        // Simuliert die Rückgabe eines Kundenobjekts beim Aufruf der findById-Methode des Repositories
        when(customerRepository.findById(anyLong())).thenReturn(Optional.of(customer));

        // Aufruf der Methode zum Erstellen der Rechnung
        pdfGeneratorService.generateInvoice(customerId, kwh);

        // Überprüft, ob die PDF-Datei tatsächlich erstellt wurde
        String filePath = "../invoices/invoice_" + customerId + ".pdf";
        File file = new File(filePath);
        assertTrue(file.exists());

        // Löscht die erstellte Datei nach dem Test, um das Dateisystem sauber zu halten
        FileSystemUtils.deleteRecursively(new File("../invoices/invoice_1.pdf"));
    }
}
