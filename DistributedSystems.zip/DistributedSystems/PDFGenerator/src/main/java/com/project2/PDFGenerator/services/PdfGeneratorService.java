package com.project2.PDFGenerator.services;

import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class PdfGeneratorService {

    private static final Logger logger = LoggerFactory.getLogger(PdfGeneratorService.class);

    @Autowired
    private CustomerRepository customerRepository;

    public void generateInvoice(Long customerId, Double kwh) {
        logger.info("Generating invoice for customer ID: {}", customerId);

        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> {
            logger.error("Customer not found: {}", customerId);
            return new RuntimeException("Customer not found");
        });

        Document document = new Document();
        try {
            String invoiceDirectory = "../invoices";
            File dir = new File(invoiceDirectory);
            if (!dir.exists()) {
                if (dir.mkdirs()) {
                    logger.info("Created invoice directory: {}", invoiceDirectory);
                } else {
                    logger.error("Failed to create invoice directory: {}", invoiceDirectory);
                    throw new IOException("Failed to create directory");
                }
            }

            String filePath = invoiceDirectory + "/invoice_" + customerId + ".pdf";
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            document.add(new Paragraph("Invoice for Customer ID: " + customerId));
            document.add(new Paragraph("First Name: " + customer.getFirstname()));
            document.add(new Paragraph("Last Name: " + customer.getLastname()));
            document.add(new Paragraph("Collected kwh: " + kwh));

            document.close();
            logger.info("Invoice generated successfully for customer ID: {} at {}", customerId, filePath);
        } catch (DocumentException | IOException e) {
            logger.error("Error generating invoice for customer ID: {}", customerId, e);
            throw new RuntimeException("Error generating invoice", e);
        }
    }
}
