package com.project2.StationDataCollector.dao;

import com.project2.StationDataCollector.entity.Charge;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ChargeDao {

    private final JdbcTemplate jdbcTemplate1;
    private final JdbcTemplate jdbcTemplate2;
    private final JdbcTemplate jdbcTemplate3;

    public ChargeDao(@Qualifier("db1") JdbcTemplate jdbcTemplate1,
                     @Qualifier("db2") JdbcTemplate jdbcTemplate2,
                     @Qualifier("db3") JdbcTemplate jdbcTemplate3) {
        this.jdbcTemplate1 = jdbcTemplate1;
        this.jdbcTemplate2 = jdbcTemplate2;
        this.jdbcTemplate3 = jdbcTemplate3;
    }

    public List<Charge> findByCustomerId(Long customerId) {
        String sql = "SELECT id, customer_id, kwh FROM charge WHERE customer_id = ?";

        List<Charge> charges1 = jdbcTemplate1.query(sql, new ChargeRowMapper(), customerId);
        List<Charge> charges2 = jdbcTemplate2.query(sql, new ChargeRowMapper(), customerId);
        List<Charge> charges3 = jdbcTemplate3.query(sql, new ChargeRowMapper(), customerId);

        charges1.addAll(charges2);
        charges1.addAll(charges3);

        return charges1;
    }

    private static class ChargeRowMapper implements RowMapper<Charge> {
        @Override
        public Charge mapRow(ResultSet rs, int rowNum) throws SQLException {
            Charge charge = new Charge();
            charge.setId(rs.getLong("id"));
            charge.setCustomerId(rs.getLong("customer_id"));
            charge.setKwh(rs.getDouble("kwh"));
            return charge;
        }
    }
}
