package com.project2.StationDataCollector.listener;

import com.project2.StationDataCollector.services.ChargeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StationDataListener {
    private static final Logger log = LoggerFactory.getLogger(StationDataListener.class);

    @Autowired
    private ChargeService chargeService;

    @RabbitListener(queues = "stationDataQueue")
    public void receiveMessage(Long customerId) {
        log.info("Received message with customerId: {}", customerId);
        chargeService.collectAndSendData(customerId);
    }
}
