package com.project2.StationDataCollector.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class DatasourceConfig {

    @Bean(name = "db1")
    public JdbcTemplate jdbcTemplate1() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl("jdbc:postgresql://localhost:30011/stationdb");
        hikariConfig.setUsername("postgres");
        hikariConfig.setPassword("postgres");
        DataSource dataSource = new HikariDataSource(
                hikariConfig
        );
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "db2")
    public JdbcTemplate jdbcTemplate2() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl("jdbc:postgresql://localhost:30012/stationdb");
        hikariConfig.setUsername("postgres");
        hikariConfig.setPassword("postgres");
        DataSource dataSource = new HikariDataSource(
                hikariConfig
        );
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "db3")
    public JdbcTemplate jdbcTemplate3() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl("jdbc:postgresql://localhost:30013/stationdb");
        hikariConfig.setUsername("postgres");
        hikariConfig.setPassword("postgres");
        DataSource dataSource = new HikariDataSource(
                hikariConfig
        );
        return new JdbcTemplate(dataSource);
    }

}
