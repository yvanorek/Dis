package com.project2.StationDataCollector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EnableJpaRepositories("com.project2.StationDataCollector.repository")
@EntityScan("com.project2.StationDataCollector.entity")
public class StationDataCollectorApplication {
	public static void main(String[] args) {
		SpringApplication.run(StationDataCollectorApplication.class, args);
	}
}
