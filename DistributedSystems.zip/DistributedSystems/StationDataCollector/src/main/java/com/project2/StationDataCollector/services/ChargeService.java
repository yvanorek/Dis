package com.project2.StationDataCollector.services;

import com.project2.StationDataCollector.dao.ChargeDao;
import com.project2.StationDataCollector.config.RabbitMQConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChargeService {
    private static final Logger log = LoggerFactory.getLogger(ChargeService.class);

    @Autowired
    private ChargeDao chargeDao;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void collectAndSendData(Long customerId) {
        double totalKwh = chargeDao.findByCustomerId(customerId)
                .stream()
                .mapToDouble(charge -> charge.getKwh())
                .sum();

        String routingKey = RabbitMQConfig.KWH_QUEUE;
        log.info("Total kWh for customer {}: {}", customerId, totalKwh);

        rabbitTemplate.convertAndSend(routingKey, totalKwh);
    }
}
