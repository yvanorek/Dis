package com.project2.StationDataCollector;

import com.project2.StationDataCollector.dao.ChargeDao;
import com.project2.StationDataCollector.config.RabbitMQConfig;
import com.project2.StationDataCollector.entity.Charge;
import com.project2.StationDataCollector.services.ChargeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;

public class ChargeServiceTest {

    // Mock dependencies
    @Mock
    private ChargeDao chargeDao;

    @Mock
    private RabbitTemplate rabbitTemplate;

    // Inject mocks into the service being tested
    @InjectMocks
    private ChargeService chargeService;

    // Initialize mocks before each test
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Test the service method with a list of charges
    @Test
    public void testCollectAndSendDataWithCharges() {
        Long customerId = 1L;
        // Create a list of Charge objects to be returned by the mocked ChargeDao
        List<Charge> charges = Arrays.asList(
                createCharge(1L, customerId, 10.5),
                createCharge(2L, customerId, 20.0)
        );

        // Define the behavior of the mocked ChargeDao
        when(chargeDao.findByCustomerId(customerId)).thenReturn(charges);

        // Call the method under test
        chargeService.collectAndSendData(customerId);

        // Calculate the expected total kWh
        double expectedTotalKwh = 30.5;
        // Verify that the RabbitTemplate's convertAndSend method was called with the expected arguments
        verify(rabbitTemplate, times(1)).convertAndSend(RabbitMQConfig.KWH_QUEUE, expectedTotalKwh);
        // Verify that the ChargeDao's findByCustomerId method was called once
        verify(chargeDao, times(1)).findByCustomerId(customerId);
    }

    // Test the service method with an empty list of charges
    @Test
    public void testCollectAndSendDataWithNoCharges() {
        Long customerId = 1L;

        // Define the behavior of the mocked ChargeDao to return an empty list
        when(chargeDao.findByCustomerId(customerId)).thenReturn(Collections.emptyList());

        // Call the method under test
        chargeService.collectAndSendData(customerId);

        // Define the expected total kWh as 0.0
        double expectedTotalKwh = 0.0;
        // Verify that the RabbitTemplate's convertAndSend method was called with the expected arguments
        verify(rabbitTemplate, times(1)).convertAndSend(RabbitMQConfig.KWH_QUEUE, expectedTotalKwh);
        // Verify that the ChargeDao's findByCustomerId method was called once
        verify(chargeDao, times(1)).findByCustomerId(customerId);
    }

    // Helper method to create Charge objects
    private Charge createCharge(Long id, Long customerId, Double kwh) {
        Charge charge = new Charge();
        charge.setId(id);
        charge.setCustomerId(customerId);
        charge.setKwh(kwh);
        return charge;
    }
}
